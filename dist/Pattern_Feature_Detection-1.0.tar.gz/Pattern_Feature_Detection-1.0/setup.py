from distutils.core import setup
setup(
    name = 'Pattern_Feature_Detection',
    version='1.0',
    py_modules=['PFD'],
)